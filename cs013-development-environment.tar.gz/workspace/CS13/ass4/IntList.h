//  =============== BEGIN ASSESSMENT HEADER ================
/// @file IntList.h
/// @brief IntList class header file
/// 
/// @author Bradley Evans [bevan006@ucr.edu]
/// @date March 09, 2016
///
/// @par Plagiarism Section
/// I hereby certify that I have not received assistance on this assignment,
/// or used code, from ANY outside source other than the instruction team.
//  ================== END ASSESSMENT HEADER ===============

#ifndef INTLIST_H
#define INTLIST_H

#include <iostream>

using namespace std;

struct IntNode {
    int data;
    IntNode *next;
    IntNode(int data) : data(data), next(0) {}
};

class IntList {
    private:
        IntNode* head;
        IntNode* tail;
    public:
        // ACCESSORS::--------------------
        //initialize an empty list
        IntList();
        // deallocate all remaining dynamically allocated memory
        ~IntList(); 
        //displays all int values stored in list, each seperated with a space.
        //do not output a newline or space at the end.
        void display() const; 
        // MUTATORS:--------------------
        // insert a data value within a new node at the front end fo the list
        void push_front( int value );
        // insert a data value within a new node at the back end of the list
        void push_back( int value );
        // remove node at the front of the list
        void pop_front();
        // sort list into ascending order using selection sort algorithm
        void select_sort();
        //assumes the values in the list are sorted, inserts data into
        //into the appropriate position. do not call select sort.
        void insert_sorted( int value );
        // remove nodes containing duplicates of a pre-existing value.
        // do not assume data is sorted. do not call for a sor
        void remove_duplicates();
};

#endif