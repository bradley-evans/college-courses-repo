//  =============== BEGIN ASSESSMENT HEADER ================
/// @file main.cpp
/// @brief IntList class main file
/// 
/// @author Bradley Evans [bevan006@ucr.edu]
/// @date March 09, 2016
///
/// @par Plagiarism Section
/// I hereby certify that I have not received assistance on this assignment,
/// or used code, from ANY outside source other than the instruction team.
//  ================== END ASSESSMENT HEADER ===============

#include <iostream>
#include "IntList.h"

using namespace std;

int main() {
    int arr[10] =  {0,1,2,3,4,5,6,7,8,9};
    int arr2[10] = {89,23,22,89,89,335,335,834,335,897};
    int arr3[7] = {89,89,335,335,834,335,897};
    int i=0;
    
    // TEST 1 =======================================
    cout << "Start Test 1:" << endl;
    IntList list1;
    cout << "  Push back 10 elements: ";
    for (i=0;i<10;i++) {
        list1.push_back(arr[i]);
    }
    list1.display();
    cout << endl;
    
    // TEST 2 =======================================
    cout << "Start Test 2:" << endl;
    IntList list2;
    cout << "  Push back 10 elements: ";
    for (i=0;i<10;i++) {
        list2.push_back(arr2[i]);
    }
    list2.display();
    cout << endl;
    cout << "  Push front 10 elements: ";
    for (i=0;i<10;i++) {
        list2.push_front(arr[i]);
    }
    list2.display();
    cout << endl;
    cout << "  Pop front 10 elements: ";
    for (i=0;i<10;i++) {
        list2.pop_front();
    }
    list2.display();
    cout << endl;
    cout << "  Remove duplicates: ";
    list2.remove_duplicates();
    list2.display();
    cout << endl;
    cout << "  Selection sort: ";
    list2.select_sort();
    list2.display();
    cout << endl;
    
    // TEST 3 =======================================
    cout << "Start Test 3:" << endl;
    IntList* ptrList;
    ptrList = new IntList();
    cout << "  Made new IntList* ptrList." << endl;
    for (i=0;i<10;i++) {
        ptrList->push_back(arr[i]);
    }
    cout << "  Populated list." << endl;
    delete ptrList;
    
    // TEST 4 ========================================
    cout << "Start Test 4, the Empty List: " << endl;
    IntList* emptyList;
    emptyList = new IntList();
    cout << "  Populating." << endl;
    for (i=0;i<10;i++) {
        emptyList->push_back(arr[i]);
    }
    cout << "  Clearing." << endl;
    for (i=0;i<10;i++) {
        emptyList->pop_front();
    }
    cout << "  Displaying." << endl;
    emptyList->display();
    cout << "  Deleting." << endl;
    delete emptyList;
    cout << "Empty list tests successful." << endl;
    
    //TEST 5==========================================
    cout << "Start test 5, remove duplicates from given list." << endl;
    IntList *dupeList;
    dupeList = new IntList();
    for (i=0;i<7;i++) {
        dupeList->push_back(arr3[i]);
    }
    dupeList->display();
    cout << endl;
    cout << "Removing duplicates." << endl;
    dupeList->remove_duplicates();
    dupeList->display();
    cout << endl;
    
    cout << endl << endl << "END." << endl;
}