//  =============== BEGIN ASSESSMENT HEADER ================
/// @file IntList.cpp
/// @brief IntList class implementation file
/// 
/// @author Bradley Evans [bevan006@ucr.edu]
/// @date March 09, 2016
///
/// @par Plagiarism Section
/// I hereby certify that I have not received assistance on this assignment,
/// or used code, from ANY outside source other than the instruction team.
//  ================== END ASSESSMENT HEADER ===============

#include "IntList.h"

// ACCESSORS::--------------------
//initialize an empty list

IntList::IntList(){
    this->head = 0;
    this->tail = 0;
} 

// deallocate all remaining dynamically allocated memory
IntList::~IntList(){
    
    //cout << "Starting delete..." << endl;
    IntNode* currNode;
    IntNode* nextNode;
    if (this->head!=0) {
        currNode = this->head;
        if (head->next != 0) {
            nextNode = head->next;
        } 
        while (currNode != this->tail) {
            delete currNode;
            currNode = nextNode;
            if (currNode != this->tail) {
                nextNode = currNode->next;
            } 
        }
        delete currNode;
    } 
    //cout << "Delete success!" << endl;
}
//displays all int values stored in list, each seperated with a space.
//do not output a newline or space at the end.
void IntList::display() const {
    IntNode* currNode = this->head;
    //IntNode* nextNode = 0;

    if (head!=0 && head!=tail) {
        while (currNode!=this->tail) {
            cout << currNode->data;
            cout << " ";
            currNode = currNode->next;
        }
        cout << currNode->data;
    } else if (head==tail && head!=0) {
        cout << head->data;
    } else if (head==0) {
        //don't do anything
    }
} 
// MUTATORS:--------------------
// insert a data value within a new node at the front end fo the list
void IntList::push_front( int value ){
    IntNode* newNode;
    newNode = new IntNode(value);
    if (this->head==0) {
        this->head = newNode;
        this->tail = newNode;
    } else {
        newNode->next = this->head;
        this->head = newNode;
    }
}
// insert a data value within a new node at the back end of the list
void IntList::push_back( int value ){
    IntNode* newNode;
    newNode = new IntNode(value);
    if (this->head==0) {
        head = newNode;
        tail = newNode;
    } else {
        tail->next=newNode;
        this->tail=newNode;
    }
}
// remove node at the front of the list
void IntList::pop_front(){
    IntNode* oldHead;
    if (this->head!=0) {
        oldHead = this->head;
        if (this->head==this->tail) {
            delete oldHead;
            this->head = 0;
            this->tail = 0;
        } else if (this->head!=this->tail) {
            this->head = head->next;
            delete oldHead;
        }
    }
}
// sort list into ascending order using selection sort algorithm
void IntList::select_sort(){
    if (head!=0) {
        
        IntNode* index = this->head;
        IntNode* currMin = this->head;
        IntNode* compare = this->head;
        int tempA = 0;
        int tempB = 0;
        bool firstRun = true;
        
        do {      
            if (!firstRun) {
                index = index->next;
                compare = index;
                currMin = index;
            }
            firstRun = false;
            do {
                if (compare->next != 0) {
                    compare = compare->next;
                }
                if (compare->data < currMin->data) {
                    currMin = compare;
                }
            } while (compare != this->tail);
            // swap
            tempA = index->data;
            tempB = currMin->data;
            index->data = tempB;
            currMin->data = tempA;
            // advance to next index for next iteration

        }  while (index != this->tail);
    } 
}
//assumes the values in the list are sorted, inserts data into
//into the appropriate position. do not call select sort.
void IntList::insert_sorted( int value ){
    cout << value;
}
// remove nodes containing duplicates of a pre-existing value.
// do not assume data is sorted. do not call for a sor
void IntList::remove_duplicates(){
    IntNode* index = this->head;
    IntNode* previous = this->head;
    IntNode* compare = index->next;
    
    while (index != this->tail) {
        while (compare != this->tail) {
            if (index->data == compare->data) {
                if (compare == this->tail) {
                    this->tail = previous;
                } else {
                    previous->next = compare->next;
                }
                delete compare;
                compare = previous;
            } else {
                previous = previous->next;
            }
            compare = compare->next;
        }
        index = index->next;
        compare = index->next;
        previous = index;
    }
}