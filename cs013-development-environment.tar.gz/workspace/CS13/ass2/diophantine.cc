//  =============== BEGIN ASSESSMENT HEADER ================
/// @file diophantine.cpp
/// @brief diophantine algorithm
/// 
/// @author Bradley Evans [bevan006@ucr.edu]
/// @date Feb 19, 2016
///
/// @par Plagiarism Section
/// I hereby certify that I have not received assistance on this assignment,
/// or used code, from ANY outside source other than the instruction team.
//  ================== END ASSESSMENT HEADER ===============

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <stdlib.h> // for abs function
using namespace std;

int gcd ( int a, int b ) {
    int i=1;
    int num_gcd=1;
    for (i=2; i<=abs(a) && i<=abs(b); i++) {
        if (a%i==0 && b%i==0) {
            num_gcd=i;
        }
    }
    return num_gcd;
}

// use a bool function here, return false if there was no solution
bool diophantine( int a, int b, int c, int &x, int &y ) {
    
    int u, v, q, r;
    
    if ( c % gcd(a,b) != 0 ) {
        // if C is not divisible by GCD, No solution found.
        return false;
    } else if ( a%b == 0 ) {
        // simplest case: if a%b==0, then x=0, y=c/b
        // solution is found.
        x = 0;
        y = c/b;
        return true;
    } else {
        // if all else fails, use substitution method
        // go recursive
        q = (a/b);
        r = (a%b);
        if (!diophantine(b, r, c, u, v)){
            return false;
        } else {
            x = v;
            y = u - (q * x);
            return true;
        }
    }
}

int main() {
    
    int a, b, c; // coefficent for equation
    int x, y; // solutions
    
    // Take input from a file. Each line of the file
    // will contain the three values, x coefficient,
    // y coefficient, and c for a particular Diophante
    // equation, each value seperated by a space.
    fstream input, output;
    string infile, outfile;
    
    cin >> infile;
    cin >> outfile;
    
    input.open (infile.c_str(), fstream::in);
    output.open (outfile.c_str(), fstream::out);
    
    while (!input.eof()) {
        input >> a;
        input >> b;
        input >> c;
        
        // Solve using the recursive version of the extended
        // Euclidian algorithm for finding the integers x
        // and y in Bezout's identity
        if (!diophantine(a,b,c,x,y)) {
            output << "No solution!" << "\n";
        } else {
            output << x << " " << y << "\n";
        }
    }
    
    
    
    // Output solutions to another file.
    input.close();
    output.close();
}

