#include <iostream>
using namespace std;

const int SIZE=6;

int arr[SIZE]={5,3,2,1,7,5}

int i, j;
int temp;

cout << "Unsorted: ";
for (i=0;i<SIZE;i++) {
    cout << arr[i] << " ";
}
cout << endl;

for (i=0;i<SIZE-1;i++) {
	for (j=0; j<SIZE-1, j++) {
		if (arr[i] > arr[i+1+j]) {
			arr[i]=temp;
			arr[i]=arr[i+1+j];
			arr[i+1+j]=temp;
		}
	}
}

cout << "Sorted: ";
for (i=0;i<SIZE;i++) {
    cout << arr[i] << " ";
}
cout << endl;