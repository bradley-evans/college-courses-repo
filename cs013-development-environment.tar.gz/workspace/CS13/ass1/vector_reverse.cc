#include <vector>
#include <iostream>

using namespace std;

int main() {
    vector<char> vecforward(26);
    int i = 0;
    
    for (i=0;i<26;i++) {
        vecforward.at(i) = ('a'+i);
    }
    
    cout << "Starting Vector: ";
    for (i=0;i<26;i++) {
        cout << vecforward.at(i);
    }
    cout << endl;
    
    // lets do this
    
    vector<char> vecback(vecforward.size());
    for (i=0;i<vecforward.size();i++) {
        vecback.at(i) = vecforward.at(vecforward.size()-1-i);
    }
    cout << "Ending Vector: ";
    for (i=0;i<26;i++) {
        cout << vecback.at(i);
    }
    cout << endl;
    
    return 0;
    
}