//  =============== BEGIN ASSESSMENT HEADER ================
/// @file wordsearch.cpp
/// @brief Word Search assignment for CS 013 Winter 2016
/// 
/// @author Bradley Evans [bevan006@ucr.edu]
/// @date January 13, 2016
///
/// @par Plagiarism Section
/// I hereby certify that I have not received assistance on this assignment,
/// or used code, from ANY outside source other than the instruction team.
//  ================== END ASSESSMENT HEADER ===============

#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

// The puzzle will always have exactly 20 columns
const int numCols = 20;

void searchPuzzle(const char puzzle[][numCols], const string wordBank[], 
    vector <string> &discovered, int numRows, int numWords);

void printVector(const vector <string> &v);

int main() {
    int numRows, numWords;
    int i=0,j=0; // iterators
    // grab the array row dimension and amount of words
    cin >> numRows >> numWords;
    
    // declare a 2D array
    char puzzle[numRows][numCols];
    
    // TODO: fill the 2D array via input
    // read the puzzle in from the input file using cin
    // It seems like rSub is going to cycle through the cin for me? 
    //That's easier.
    for (i=0;i<numRows;i++) {
        for (j=0;j<numCols;j++) {
            cin >> puzzle[i][j];
        }
    }
    
    // create a 1D array for wods
    string wordBank[numWords];
    
    // TODO: fill the wordBank through input using cin
    for (i=0;i<numWords;i++) {
        cin >> wordBank[i];
    }

    // set up discovery vector
    vector <string> discovered;

    // Search for Words
    searchPuzzle(puzzle, wordBank, discovered, numRows, numWords);

    // TODO: search Google for sorting a vector for examples
    // Sort the results
    sort(discovered.begin(), discovered.end());
    
    // Print vector of discovered words
    printVector(discovered);
    
    return 0;
}

// TODO: implement searchPuzzle and any helper functions you want
void searchPuzzle(const char puzzle[][numCols], const string wordBank[], 
    vector <string> &discovered, int numRows, int numWords) {
    int numDiscovered = 0;
    string currentRow;
    int i,j,k; // iterators
    int wordLength;
    int arrayCharSize = (numCols * numRows);
    // derivative arrays
    char puzzleInverse[numCols][numRows];
    char puzzleHorizMirror[numRows][numCols];
    char puzzleInverseHorizMirror[numCols][numRows];
    char puzzleTLBR[arrayCharSize];
    char puzzleTLBRreversed[arrayCharSize];
    char puzzleTRBL[arrayCharSize];
    char puzzleTRBLreversed[arrayCharSize];
    int x, y; // array iterators

    // create an inverse array
    for (i=0;i<numRows;i++) {
        for (j=0;j<numCols;j++) {
            puzzleInverse[j][i] = puzzle[i][j];
        }
    }
    // create a horizontally mirrored array
    for (i=0;i<numRows;i++) {
        k=numCols-1;
        for (j=0;j<numCols;j++) {
            puzzleHorizMirror[i][j]=puzzle[i][k];
            k--;
        }
    }
    // create a horizontal mirror of the inverse array
    for (i=0;i<numCols;i++) {
        k=numRows-1;
        for (j=0;j<numRows;j++) {
            puzzleInverseHorizMirror[i][j]=puzzleInverse[i][k];
            k--;
        }
    }
    // diagonal array, top left to bottom right, and its reverse

    k=0;
    for (i=1;i<numRows;i++) {
        x = 0;
        y = numRows-i;
        //cout << "Down and Right: ";
        do {
            puzzleTLBR[k] = puzzle[y][x];
            //cout << puzzleTLBR[k];
            if (puzzleTLBR[k]=='\0') {
                puzzleTLBR[k]=' ';
            }
            k++;
            x++;
            y++;
        } while (x<numCols && y<numRows);
        //cout << endl;
    }
    for (i=0;i<numCols;i++) {
        x = i;
        y = 0;
        //cout << "Down and Right: ";
        do {
            puzzleTLBR[k] = puzzle[y][x];
            //cout << puzzleTLBR[k];
            if (puzzleTLBR[k]=='\0') {
                puzzleTLBR[k]=' ';
            }
            k++;
            x++;
            y++;
        } while (x<numCols && y<numRows);
        //cout << endl;
    }
    j=arrayCharSize-1;
    for (i=0;i<arrayCharSize;i++) {
        puzzleTLBRreversed[i]=puzzleTLBR[j];
        if (puzzleTLBRreversed[i]=='\0') {
            puzzleTLBRreversed[i]==' ';
        }
        j--;
    }
    for (i=0;i<arrayCharSize;i++) {
        if (puzzleTLBRreversed[i] == '\0') {
            puzzleTLBRreversed[i]=' ';
        }
    }
    puzzleTLBRreversed[arrayCharSize-1]='\0';
    // diagonal array, top right to bottom left, and its reverse
    k=0;
    for (i=1;i<numCols;i++) {
        x = i;
        y = 0;
        do {
            puzzleTRBL[k]=puzzle[y][x];
            if (puzzleTRBL[k]=='\0') {
                puzzleTRBL[k]=' ';
            }
            k++;
            x--;
            y++;
        } while (x>=0 && y<=numRows);
    }
    for (i=1;i<numRows;i++) {
        x = numCols-1;
        y = i;
        do {
            puzzleTRBL[k]=puzzle[y][x];
            if (puzzleTRBL[k]=='\0') {
                puzzleTRBL[k]=' ';
            }
            k++;
            x--;
            y++;
        } while (x>=0 && y<numRows);
    }
    j=arrayCharSize-1;
    for (i=0;i<arrayCharSize;i++) {
        puzzleTRBLreversed[i]=puzzleTRBL[j];
        if (puzzleTRBLreversed[i]=='\0') {
            puzzleTRBLreversed[i]==' ';
        }
        j--;
    }
    for (i=0;i<arrayCharSize;i++) {
        if (puzzleTRBLreversed[i] == '\0') {
            puzzleTRBLreversed[i]=' ';
        }
    }
    puzzleTRBLreversed[arrayCharSize-1]='\0';
    
    /* We'll look for words one at a time. This probabaly isn't the most
    efficient way but it may be the simplest implementation. */
    for (i=0;i<numWords;i++) {
        wordLength = wordBank[i].size();
        
        // search horizontally
        for (j=0;j<numRows;j++) {           // iterate through rows
            currentRow = string(puzzle[j]); // current row is stored as a string
            
            for (k=0;k<=(numCols-wordLength);k++) {      // iterate through cols
                if (currentRow.substr(k,wordLength) == wordBank[i]) {
                    discovered.push_back(wordBank[i]);
                    break;
                }
            }
        }
        // search vertically
        for (j=0;j<numCols;j++) {           // iterate through columns
            // current column is stored as a string
            currentRow = string(puzzleInverse[j]); 
            
            for (k=0;k<=(numRows-wordLength);k++) {      // iterate through rows
                //compare substrings
                if (currentRow.substr(k,wordLength) == wordBank[i]) {
                    discovered.push_back(wordBank[i]);
                    break;
                }
            }
        }
        // search horizontally, in reverse
        for (j=0;j<numRows;j++) {          
            currentRow = string(puzzleHorizMirror[j]); 
            for (k=0;k<=(numCols-wordLength);k++) {    
                if (currentRow.substr(k,wordLength) == wordBank[i]) {
                    discovered.push_back(wordBank[i]);
                    break;
                }
            }
        }
        // search vertically, in reverse
        for (j=0;j<numCols;j++) {
            currentRow = string(puzzleInverseHorizMirror[j]); 
            for (k=0;k<=(numRows-wordLength);k++) {
                if (currentRow.substr(k,wordLength) == wordBank[i]) {
                    discovered.push_back(wordBank[i]);
                    break;
                }
            }
        }
        // search diagonally, top left to bottom right, then again backwards
        currentRow = string(puzzleTLBR); 
        //cout << "TLBR: " << currentRow << endl; 
        int rowSize = currentRow.size();
        // go forwards
        for (k=0;k<rowSize-wordLength;k++) {
            if (currentRow.substr(k,wordLength) == wordBank[i]) {
                discovered.push_back(wordBank[i]);
                break;
            }
        }
        // now backwards
        currentRow = string(puzzleTLBRreversed);
        //cout << "TLBR reversed: " << currentRow << endl; 
        rowSize = currentRow.size();
        for (k=0;k<rowSize-wordLength;k++) {
            if (currentRow.substr(k,wordLength) == wordBank[i]) {
                discovered.push_back(wordBank[i]);
                break;
            }
        }
        // now diagonally top right to bottom left
        currentRow = string(puzzleTRBL);
        //cout << "TRBL: " << currentRow << endl; 
        rowSize = currentRow.size();
        // go forwards
        for (k=0;k<rowSize-wordLength;k++) {
            if (currentRow.substr(k,wordLength) == wordBank[i]) {
                discovered.push_back(wordBank[i]);
                break;
            }
        }
        // now backwards
        currentRow = string(puzzleTRBLreversed);
        //cout << "TRBL reversed: " << currentRow << endl; 
        rowSize = currentRow.size();
        for (k=0;k<rowSize-wordLength;k++) {
            if (currentRow.substr(k,wordLength) == wordBank[i]) {
                discovered.push_back(wordBank[i]);
                break;
            }
        }
    }
}


// TODO: implement printVector
void printVector(const vector <string> &v) {
    int vecSize = v.size();
    int i = 0;
    
    for (i=0;i<vecSize;i++) {
        cout << v.at(i) << endl;
    }
}