//  =============== BEGIN ASSESSMENT HEADER ================
/// @file Date.cpp
/// @brief Implementation file for Date class
/// 
/// @author Bradley Evans [bevan006@ucr.edu]
/// @date Feburary 23, 2016
///
/// @par Plagiarism Section
/// I hereby certify that I have not received assistance on this assignment,
/// or used code, from ANY outside source other than the instruction team.
//  ================== END ASSESSMENT HEADER ===============


#include "Date.h"

/*
PUBLIC MEMBER FUNCTIONS
*/

Date::Date() {
    this->day = 1;
    this->month = 1;
    this->year = 2000;
    this->monthName = "January";
}

Date::Date(unsigned m, unsigned d, unsigned y) {
    // parameterized constructer, num m/d/y
    bool isError = false;
    if ( m<=12 && m>=1 ) {
        this->month = m;
    } else if ( m<1 ) {
        this->month = 1;
        isError=true;
    } else if ( m>12 ) {
        this->month = 12;
        isError=true;
    }
    this->year = y;
    unsigned maxDays = daysPerMonth(this->month,this->year);
    if ( d<1 ) {
        this->day = 1;
        isError=true;
    } else if ( d>maxDays ) {
        this->day = maxDays;
        isError=true;
    } else {
        this->day = d;
    }
    this->monthName=name(this->month);
    if (isError) {
        cout << "Invalid date values: Date corrected to ";
        printNumeric();
        cout << endl;
    }
}

Date::Date(const string &mn, unsigned d, unsigned y) {
    // parameterized constructor, word m/d/y
    bool isError = false;
    bool isMonthError = false;
    unsigned numMonth = number(mn);
    this->year = y;
    if (numMonth == 13) {
        this->month = 1;
        isMonthError=true;
    } else { 
        this->month=numMonth;
    }
    unsigned maxDays = daysPerMonth(this->month,this->year);
    if ( d<1 ) {
        this->day = 1;
        isError=true;
    } else if ( d>maxDays ) {
        this->day = maxDays;
        isError=true;
    } else {
        this->day = d;
    }
    this->monthName=name(this->month);
    if (isMonthError) {
        cout << "Invalid month name: the Date was set to ";
        printNumeric();
        cout << endl;
    }
    if (isError && !isMonthError) {
        cout << "Invalid date values: Date corrected to ";
        printNumeric();
        cout << endl;
    }
}
void Date::printNumeric() const {
    // print numeric date ##/##/####
    cout << this->month << "/" << this->day << "/" << this->year;
    
}
void Date::printAlpha() const {
    // print alphabetic date MMMM ##, #### 
    string suffix;
    cout << this->monthName << " " << this->day << ", " << this->year;
    
}

/*
PRIVATE MEMBER FUNCTIONS
*/

bool Date::isLeap(unsigned y) const {
    if (y%4==0 && y%100!=0) {
        return true;
    } else if (y%400==0) {
        return true;
    } else {
        return false;
    }
}
unsigned Date::daysPerMonth(unsigned m, unsigned y) const {
    // returns number of days allowed in a given month
    vector<unsigned> monthLength(12);
    monthLength.at(0)=31;
    monthLength.at(1)=28;
    monthLength.at(2)=31;
    monthLength.at(3)=30;
    monthLength.at(4)=31;
    monthLength.at(5)=30;
    monthLength.at(6)=31;
    monthLength.at(7)=31;
    monthLength.at(8)=30;
    monthLength.at(9)=31;
    monthLength.at(10)=30;
    monthLength.at(11)=31;
    if (isLeap(y)) {
        monthLength.at(1) = 29;
    }
    return monthLength.at(m-1);
}
string Date::name(unsigned m) const {
    // returns name of a given month
    vector<string> months(12);
    months.at(0)="January";
    months.at(1)="February";
    months.at(2)="March";
    months.at(3)="April";
    months.at(4)="May";
    months.at(5)="June";
    months.at(6)="July";
    months.at(7)="August";
    months.at(8)="September";
    months.at(9)="October";
    months.at(10)="November";
    months.at(11)="December";
    return months.at(m-1);
}
unsigned Date::number(const string &mn) const {
    vector<string> months(12);
    months.at(0)="January";
    months.at(1)="February";
    months.at(2)="March";
    months.at(3)="April";
    months.at(4)="May";
    months.at(5)="June";
    months.at(6)="July";
    months.at(7)="August";
    months.at(8)="September";
    months.at(9)="October";
    months.at(10)="November";
    months.at(11)="December";
    unsigned i = 0;
    string teststring = mn;
    teststring[0] = toupper(teststring[0]);
    for (i=0;i<12;i++) {
        if (months.at(i)==teststring) {
            return i+1;
        }
    }
    // if month not found, then return 13 as an error
    return 13;
   
}
Date Date::addDays(int n) const {
    int daysToAdd=0;
    unsigned newDay=this->day;
    unsigned newMonth=this->month;
    unsigned newYear=this->year;
    int maxDays=daysPerMonth(newMonth,newYear);
    if (n>0) {
        daysToAdd=n;
        while (daysToAdd>0) {
            if (newDay < maxDays) {
                newDay = newDay + 1;
                daysToAdd--;
            } else if (newDay == maxDays && newMonth < 12) {
                newDay = 1;
                newMonth = newMonth + 1;
                maxDays=daysPerMonth(newMonth,newYear);
                daysToAdd--;
            } else if (newDay == maxDays && newMonth == 12) {
                newYear = newYear + 1;
                newMonth = 1;
                newDay = 1;
                maxDays=daysPerMonth(newMonth,newYear);
                daysToAdd--;
            }
        }
    } else if (n<0) {
        daysToAdd=abs(n);
        while (daysToAdd>0) {
            if (newDay > 1) {
                newDay = newDay - 1;
                daysToAdd--;
            } else if (newDay == 1 && newMonth > 1) {
                newMonth = newMonth - 1;
                maxDays=daysPerMonth(newMonth,newYear);
                newDay = maxDays;
                daysToAdd--;
            } else if (newDay == 1 && newMonth == 1) {
                newYear = newYear - 1;
                newMonth = 12;
                maxDays=daysPerMonth(newMonth,newYear);
                newDay = maxDays;
                daysToAdd--;
            }
        }
    }
    Date newDate(newMonth,newDay,newYear);
    return newDate;
}