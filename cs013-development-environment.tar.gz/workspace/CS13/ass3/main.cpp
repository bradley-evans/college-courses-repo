//  =============== BEGIN ASSESSMENT HEADER ================
/// @file main.cpp
/// @brief Main function / test wrapper for date class
/// 
/// @author Bradley Evans [bevan006@ucr.edu]
/// @date Feburary 23, 2016
///
/// @par Plagiarism Section
/// I hereby certify that I have not received assistance on this assignment,
/// or used code, from ANY outside source other than the instruction team.
//  ================== END ASSESSMENT HEADER ===============

#include <iostream>
#include <string>
#include "Date.h"

using namespace std;

int main() {
    // test harness for Date class
    cout << "Default constructor test." << endl;
    Date date1;
    cout << "Numeric date: ";
    date1.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date1.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Numeric user input (valid) date test." << endl;
    cout << "Trying 5-15-2015." << endl;
    Date date2(5,15,2015);
    cout << "Numeric date: ";
    date2.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date2.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Numeric user input (invalid) date test." << endl;
    cout << "Trying 15-31-2015." << endl;
    Date date3(15,31,2015);
    cout << "Numeric date: ";
    date3.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date3.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Alphabetic user input (valid, upper) date test." << endl;
    cout << "Trying \"November 10, 1775\"." << endl;
    Date date4("November",10,1775);
    cout << "Numeric date: ";
    date4.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date4.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Alphabetic user input (invalid, upper) date test." << endl;
    cout << "Trying \"Movember 10, 1775\"." << endl;
    Date date5("Movember",10,1775);
    cout << "Numeric date: ";
    date5.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date5.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Alphabetic user input (valid, lower) date test." << endl;
    cout << "Trying \"november 10, 1775\"." << endl;
    Date date6("november",10,1775);
    cout << "Numeric date: ";
    date6.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date6.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Alphabetic user input (invalid, lower) date test." << endl;
    cout << "Trying \"movember 37, 1775\"." << endl;
    Date date7("movember",37,1775);
    cout << "Numeric date: ";
    date7.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date7.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Feb 29, not a leap year date test." << endl;
    cout << "Trying 2-29-1775." << endl;
    Date date8(2,29,1775);
    cout << "Numeric date: ";
    date8.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date8.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Feb 29, IS a leap year date test." << endl;
    cout << "Trying 2-29-2004." << endl;
    Date date9(2,29,2004);
    cout << "Numeric date: ";
    date9.printNumeric();
    cout << endl;
    cout << "Alphanumeric date: ";
    date9.printAlpha();
    cout << endl << endl;
    // -----------------------------------------
    cout << "Add Date Test." << endl;
    cout << "Date 1: 1/1/2000. Adding 1024 days." << endl;
    date2 = date1.addDays(1024);
    date2.printNumeric();
    cout << endl;
    cout << "Expected: 10/21/2002" << endl;
    cout << "Now subtracting 1024 days." << endl;
    date3 = date2.addDays(-1024);
    date3.printNumeric();
    cout << endl;
    cout << "Expected: 1/1/2000." << endl;
    
}