//  =============== BEGIN ASSESSMENT HEADER ================
/// @file Date.h
/// @brief Date class header file
/// 
/// @author Bradley Evans [bevan006@ucr.edu]
/// @date Feburary 23, 2016
///
/// @par Plagiarism Section
/// I hereby certify that I have not received assistance on this assignment,
/// or used code, from ANY outside source other than the instruction team.
//  ================== END ASSESSMENT HEADER ===============

#ifndef DATE_H
#define DATE_H
 
#include <string>
#include <iostream>
#include <vector>
#include <stdlib.h> // for abs()
using namespace std;

class Date {
    private:
        unsigned day;
        unsigned month;
        string monthName;
        unsigned year;
    public:
        Date();
            // default constructor, default date
            // is Jan 1 2000.
        Date(unsigned m, unsigned d, unsigned y);
            // parameterized constructer, num m/d/y
        Date(const string &mn, unsigned d, unsigned y);
            // parameterized constructor, word m/d/y
        void printNumeric() const;
            // print numeric date ##/##/####
        void printAlpha() const;
            // print alphabetic date MMMM ##th, #### 
        Date addDays(int n) const;
    private:
        bool isLeap(unsigned y) const;
            // test for leap year
        unsigned daysPerMonth(unsigned m, unsigned y) const;
            // returns number of days allowed in a given month;
        string name(unsigned m) const;
            // returns name of a given month
        unsigned number(const string &mn) const;
            // returns number of a given named month
        
};

#endif /* DATE_H */