#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;

int main() {
    string key, sample1, sample2, sample3, compareSubString, compareKeyString;
    int overlapLength;
    
    key = "abc";
    sample1 = "defab";
    sample2 = "abcdef";
    sample3 = "bcdef";
    
    overlapLength = 3;
    
    for (;overlapLength>=0;overlapLength--) {
        compareSubString = sample1.substr(sample1.size()-overlapLength);
            cout << "compareSubString: " << compareSubString << endl;
        compareKeyString = key.substr(0,overlapLength);
            cout << "compareKeyString: " << compareKeyString << endl;
        if (compareKeyString == compareSubString) {break;}
    }
    cout << "overlapLength: " << overlapLength << endl;
    
    
    
    return 0;
}