#include <iostream>

using namespace std;

double expCalc (int base, int exponent) {
    if (exponent==0) {return 1;}
    return base * expCalc(base,exponent-1);
}
int main() {
    
    int a = 2;
    int b = 8;
    cout << expCalc(a,b);
    
}